package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.CurrentAccountDetails;

@Repository
public class CurrentAccountDetailsRepository implements CurrentAccountDetailsRepositoryInterface {
	private static final String NEXT_ACCOUNT_TYPE_ID = "select current_account_details_sequence.NEXTVAL from dual";
	private static final String INSERT_NEW_CURRENT_ACCOUNT = "insert into current_account_details(account_type_id, initial_overdraft_balance, current_overdraft_balance, current_balance) values(?,?,?,?)";
	private static final String GET_ALL_CURRENT_ACCOUNT = "select * from current_account_details";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public CurrentAccountDetails addNewCustomer(CurrentAccountDetails currentAccountDetails) {
		String accountTypeId = "CACC" + getNextAccountTypeId();
		Object[] params = { accountTypeId,
				currentAccountDetails.getIntialOverdraftBalance(), currentAccountDetails.getCurrentOverdraftBalance(),
				currentAccountDetails.getCurrentBalance() };
		if (jdbcTemplate.update(INSERT_NEW_CURRENT_ACCOUNT, params) > 0) {
			currentAccountDetails.setAccountTypeId(accountTypeId);
			return currentAccountDetails;
		}
		return null;
	}

	@Override
	public int getNextAccountTypeId() {
		int accountTypeId = jdbcTemplate.queryForObject(NEXT_ACCOUNT_TYPE_ID, Integer.class);
		return accountTypeId;
	}

	@Override
	public List<CurrentAccountDetails> getAllCurentAccount() {
		return jdbcTemplate.query(GET_ALL_CURRENT_ACCOUNT, new CurrentAccountRowMapper());
	}

	public class CurrentAccountRowMapper implements RowMapper<CurrentAccountDetails> {

		@Override
		public CurrentAccountDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			String accountTypeId = rs.getString("account_type_id");
			LocalDate openingDate = rs.getDate("opening_date").toLocalDate();
			double intialOverdraftBalance = rs.getDouble("initial_overdraft_balance");
			double currentOverdraftBalance = rs.getDouble("current_overdraft_balance");
			double currentBalance = rs.getDouble("current_balance");

			CurrentAccountDetails currentAccountDetails = new CurrentAccountDetails(accountTypeId, openingDate,
					intialOverdraftBalance, currentOverdraftBalance, currentBalance);
			return currentAccountDetails;
		}

	}

	

}
