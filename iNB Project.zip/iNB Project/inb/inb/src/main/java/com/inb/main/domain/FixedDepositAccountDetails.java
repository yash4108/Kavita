package com.inb.main.domain;

import java.time.LocalDate;
import java.util.Objects;

public class FixedDepositAccountDetails {
	private String accountTypeId;
	private LocalDate openingDate;
	private LocalDate maturityDate;
	private double initialAmount;
	private double maturityAmount;
	private FixedDepositRateOfInterest fixedDepositRateOfInterest;

	public FixedDepositAccountDetails() {
		// TODO Auto-generated constructor stub
	}

	public FixedDepositAccountDetails(String accountTypeId, LocalDate openingDate, LocalDate maturityDate,
			double initialAmount, double maturityAmount, FixedDepositRateOfInterest fixedDepositRateOfInterest) {
		super();
		this.accountTypeId = accountTypeId;
		this.openingDate = openingDate;
		this.maturityDate = maturityDate;
		this.initialAmount = initialAmount;
		this.maturityAmount = maturityAmount;
		this.fixedDepositRateOfInterest = fixedDepositRateOfInterest;
	}

	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public LocalDate getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(LocalDate maturityDate) {
		this.maturityDate = maturityDate;
	}

	public double getInitialAmount() {
		return initialAmount;
	}

	public void setInitialAmount(double initialAmount) {
		this.initialAmount = initialAmount;
	}

	public double getMaturityAmount() {
		return maturityAmount;
	}

	public void setMaturityAmount(double maturityAmount) {
		this.maturityAmount = maturityAmount;
	}

	public FixedDepositRateOfInterest getFixedDepositRateOfInterest() {
		return fixedDepositRateOfInterest;
	}

	public void setFixedDepositRateOfInterest(FixedDepositRateOfInterest fixedDepositRateOfInterest) {
		this.fixedDepositRateOfInterest = fixedDepositRateOfInterest;
	}

	@Override
	public String toString() {
		return "FixedDepositAccountDetails [accountTypeId=" + accountTypeId + ", openingDate=" + openingDate
				+ ", maturityDate=" + maturityDate + ", initialAmount=" + initialAmount + ", maturityAmount="
				+ maturityAmount + ", fixedDepositRateOfInterest=" + fixedDepositRateOfInterest + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(accountTypeId, fixedDepositRateOfInterest, initialAmount, maturityAmount, maturityDate,
				openingDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FixedDepositAccountDetails other = (FixedDepositAccountDetails) obj;
		return Objects.equals(accountTypeId, other.accountTypeId)
				&& Objects.equals(fixedDepositRateOfInterest, other.fixedDepositRateOfInterest)
				&& Double.doubleToLongBits(initialAmount) == Double.doubleToLongBits(other.initialAmount)
				&& Double.doubleToLongBits(maturityAmount) == Double.doubleToLongBits(other.maturityAmount)
				&& Objects.equals(maturityDate, other.maturityDate) && Objects.equals(openingDate, other.openingDate);
	}

}
