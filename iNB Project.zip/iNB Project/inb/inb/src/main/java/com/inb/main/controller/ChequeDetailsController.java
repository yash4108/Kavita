package com.inb.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.domain.ChequeDetails;
import com.inb.main.service.ChequeDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("chequeapi")
public class ChequeDetailsController {
	
	@Autowired
	private ChequeDetailsServiceInterface chequeDetailsService;
	
	@RequestMapping(value = "addcheque" , method = RequestMethod.POST)
	public ChequeDetails addNewChequeDetails(@RequestBody ChequeDetails chequeDetails) {
		return chequeDetailsService.addNewChequeDetails(chequeDetails);
	}
	
	@RequestMapping(value = "allchequedetails" , method = RequestMethod.GET)
	public List<ChequeDetails> getAllChequeDetails() {
		return chequeDetailsService.getAllChequeDetails();
	}
}
