package com.inb.main.service;

import java.util.List;

import com.inb.main.domain.FixedDepositAccountDetails;

public interface FixedDepositAccountDetailsServiceInterface {
	
	public FixedDepositAccountDetails addNewCustomer(FixedDepositAccountDetails fixedDepositAccountDetails);

	public List<FixedDepositAccountDetails> getAllFixedAccount();
}
