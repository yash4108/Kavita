package com.inb.main.domain;

import java.util.Objects;

public class FixedDepositRateOfInterest {
	private String fdId;
	private String validity;
	private double rateOfInterest;

	public FixedDepositRateOfInterest() {
		// TODO Auto-generated constructor stub
	}

	public FixedDepositRateOfInterest(String fdId, String validity, double rateOfInterest) {
		super();
		this.fdId = fdId;
		this.validity = validity;
		this.rateOfInterest = rateOfInterest;
	}

	public String getFdId() {
		return fdId;
	}

	public void setFdId(String fdId) {
		this.fdId = fdId;
	}

	public String getValidity() {
		return validity;
	}

	public void setValidity(String validity) {
		this.validity = validity;
	}

	public double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	@Override
	public String toString() {
		return "FixedDepositRateOfInterest [fdId=" + fdId + ", validity=" + validity + ", rateOfInterest="
				+ rateOfInterest + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(fdId, rateOfInterest, validity);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FixedDepositRateOfInterest other = (FixedDepositRateOfInterest) obj;
		return Objects.equals(fdId, other.fdId)
				&& Double.doubleToLongBits(rateOfInterest) == Double.doubleToLongBits(other.rateOfInterest)
				&& Objects.equals(validity, other.validity);
	}

}
