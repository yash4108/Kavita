package com.inb.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.CustomerDetails;
import com.inb.main.service.AccountDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("accountapi")
public class AccountDetailsController {
	
	@Autowired
	private AccountDetailsServiceInterface accountDetailsService;
	
	@RequestMapping(value = "addcustomer" , method = RequestMethod.POST)
	public AccountDetails addAccount(@RequestBody AccountDetails accountDetails) {
		return accountDetailsService.addNewCustomer(accountDetails);
	}
	
	@RequestMapping(value = "getcustomer" , method = RequestMethod.GET)
	public List<AccountDetails> getAllAccount(){
		return accountDetailsService.getAllAccounts();
	}
	
	@RequestMapping(value = "getpendingstatus" , method = RequestMethod.GET)
	public List<AccountDetails> getPendingStatusDetails() {
		return accountDetailsService.getPendingStatusDetails();
	}
	
	@RequestMapping(value = "updatestatus" , method = RequestMethod.PUT)
	public boolean updateStatus(@RequestBody AccountDetails accountDetails) {
		return accountDetailsService.updateStatus(accountDetails);
	}
	
	@RequestMapping(value = "rejectaccount" , method = RequestMethod.PUT)
	public boolean rejectAccount(@RequestBody AccountDetails accountDetails) {
		return accountDetailsService.rejectAccount(accountDetails);
	}
	
	@RequestMapping(value = "getallaccount/{accountId}" , method = RequestMethod.GET)
	public List<AccountDetails> getAccountByAccountId(@PathVariable String accountId) {
		return accountDetailsService.getAccountByAccountId(accountId);
	}
}
