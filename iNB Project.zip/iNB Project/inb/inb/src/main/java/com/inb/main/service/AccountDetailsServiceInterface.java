package com.inb.main.service;

import java.util.List;

import com.inb.main.domain.AccountDetails;

public interface AccountDetailsServiceInterface {
	
	public AccountDetails addNewCustomer(AccountDetails accountDetails);

	public List<AccountDetails> getAllAccounts(); 
	
	public List<AccountDetails> getPendingStatusDetails();
	
	public boolean updateStatus(AccountDetails accountDetails);
	
	public boolean rejectAccount(AccountDetails accountDetails);
	
	public List<AccountDetails> getAccountByAccountId(String accountId);

}
