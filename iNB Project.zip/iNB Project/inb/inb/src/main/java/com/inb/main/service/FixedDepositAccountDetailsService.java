package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.FixedDepositAccountDetails;
import com.inb.main.repository.FixedDepositAccountDetailsRepositoryInterface;

@Service
public class FixedDepositAccountDetailsService implements FixedDepositAccountDetailsServiceInterface {
	
	@Autowired
	private FixedDepositAccountDetailsRepositoryInterface fixedDepositAccountDetailsRepository;
	
	@Override
	public FixedDepositAccountDetails addNewCustomer(FixedDepositAccountDetails fixedDepositAccountDetails) {
	
		return fixedDepositAccountDetailsRepository.addNewCustomer(fixedDepositAccountDetails);
	}

	@Override
	public List<FixedDepositAccountDetails> getAllFixedAccount() {
		
		return fixedDepositAccountDetailsRepository.getAllFixedAccount();
	}

}
