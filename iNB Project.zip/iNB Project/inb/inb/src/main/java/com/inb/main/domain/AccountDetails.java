package com.inb.main.domain;

import java.util.Objects;

public class AccountDetails {
	private String accountId;
	private SavingAccountDetails savingAccountDetails;
	private CurrentAccountDetails currentAccountDetails;
	private FixedDepositAccountDetails fixedDepositAccountDetails;
	private CustomerDetails customerDetails;
	private String status;

	public AccountDetails() {
		// TODO Auto-generated constructor stub
	}

	public AccountDetails(String accountId, SavingAccountDetails savingAccountDetails,
			CurrentAccountDetails currentAccountDetails, FixedDepositAccountDetails fixedDepositAccountDetails,
			CustomerDetails customerDetails, String status) {
		super();
		this.accountId = accountId;
		this.savingAccountDetails = savingAccountDetails;
		this.currentAccountDetails = currentAccountDetails;
		this.fixedDepositAccountDetails = fixedDepositAccountDetails;
		this.customerDetails = customerDetails;
		this.status = status;
	}

	@Override
	public String toString() {
		return "AccountDetails [accountId=" + accountId + ", savingAccountDetails=" + savingAccountDetails
				+ ", currentAccountDetails=" + currentAccountDetails + ", fixedDepositAccountDetails="
				+ fixedDepositAccountDetails + ", customerDetails=" + customerDetails + ", status=" + status + "]";
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public SavingAccountDetails getSavingAccountDetails() {
		return savingAccountDetails;
	}

	public void setSavingAccountDetails(SavingAccountDetails savingAccountDetails) {
		this.savingAccountDetails = savingAccountDetails;
	}

	public CurrentAccountDetails getCurrentAccountDetails() {
		return currentAccountDetails;
	}

	public void setCurrentAccountDetails(CurrentAccountDetails currentAccountDetails) {
		this.currentAccountDetails = currentAccountDetails;
	}

	public FixedDepositAccountDetails getFixedDepositAccountDetails() {
		return fixedDepositAccountDetails;
	}

	public void setFixedDepositAccountDetails(FixedDepositAccountDetails fixedDepositAccountDetails) {
		this.fixedDepositAccountDetails = fixedDepositAccountDetails;
	}

	public CustomerDetails getCustomerDetails() {
		return customerDetails;
	}

	public void setCustomerDetails(CustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		return Objects.hash(accountId, currentAccountDetails, customerDetails, fixedDepositAccountDetails,
				savingAccountDetails, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountDetails other = (AccountDetails) obj;
		return Objects.equals(accountId, other.accountId)
				&& Objects.equals(currentAccountDetails, other.currentAccountDetails)
				&& Objects.equals(customerDetails, other.customerDetails)
				&& Objects.equals(fixedDepositAccountDetails, other.fixedDepositAccountDetails)
				&& Objects.equals(savingAccountDetails, other.savingAccountDetails)
				&& Objects.equals(status, other.status);
	}

}
