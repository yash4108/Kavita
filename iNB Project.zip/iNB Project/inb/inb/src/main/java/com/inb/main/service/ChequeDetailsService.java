package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.ChequeDetails;
import com.inb.main.repository.ChequeDetailsRepositoryInterface;

@Service
public class ChequeDetailsService implements ChequeDetailsServiceInterface {

	@Autowired
	private ChequeDetailsRepositoryInterface chequeDetailsRepository;
	
	@Override
	public ChequeDetails addNewChequeDetails(ChequeDetails chequeDetails) {
		return chequeDetailsRepository.addNewChequeDetails(chequeDetails);
	}

	@Override
	public List<ChequeDetails> getAllChequeDetails() {
		return chequeDetailsRepository.getAllChequeDetails();
	}

	@Override
	public int getNextChequeNo() {
		return chequeDetailsRepository.getNextChequeNo();
	}

}
