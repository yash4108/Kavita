package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.SavingAccountDetails;
import com.inb.main.repository.SavingAccountDetailsRepositoryInterface;

@Service
public class SavingAccountDetailsService implements SavingAccountDetailsServiceInterface {
	
	@Autowired
	private SavingAccountDetailsRepositoryInterface savingAccountDetailsRepository;

	@Override
	public SavingAccountDetails addNewCustomer(SavingAccountDetails savingAccountDetails) {
		return savingAccountDetailsRepository.addNewCustomer(savingAccountDetails);
	}

	@Override
	public List<SavingAccountDetails> getAllSavingAccount() {
		return savingAccountDetailsRepository.getAllSavingAccount();
	}

}
