package com.inb.main.service;

import com.inb.main.domain.Login;

public interface LoginServiceInterface {
	
	public Login verifyUser(Login login);
	
	public Login addNewLogin(Login login);
}
