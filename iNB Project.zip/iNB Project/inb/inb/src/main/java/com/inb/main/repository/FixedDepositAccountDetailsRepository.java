package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.FixedDepositAccountDetails;
import com.inb.main.domain.FixedDepositRateOfInterest;


@Repository
public class FixedDepositAccountDetailsRepository implements FixedDepositAccountDetailsRepositoryInterface {
	private static final String NEXT_ACCOUNT_TYPE_ID = "select fixed_deposit_account_details_sequence.NEXTVAL from dual";
	private static final String INSERT_NEW_FIXED_DEPOSIT_ACCOUNT = "insert into fixed_deposit_account_details(account_type_id, maturity_date, initial_amount, maturity_amount, fd_id) values(?,?,?,?,?)";
	private static final String GET_ALL_FIXED_DEPOSIT_ACCOUNT = "select * from fixed_deposit_account_details";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public FixedDepositAccountDetails addNewCustomer(FixedDepositAccountDetails fixedDepositAccountDetails) {
		String accountTypeId = "FID" + getNextAccountTypeId();
		Object [] params = {accountTypeId,fixedDepositAccountDetails.getMaturityDate(),fixedDepositAccountDetails.getInitialAmount(),fixedDepositAccountDetails.getMaturityAmount(),fixedDepositAccountDetails.getFixedDepositRateOfInterest().getFdId()};	
		if (jdbcTemplate.update(INSERT_NEW_FIXED_DEPOSIT_ACCOUNT,params) > 0) {
			fixedDepositAccountDetails.setAccountTypeId(accountTypeId);
			return fixedDepositAccountDetails;
		}
		return null;
	}

	@Override
	public int getNextAccountTypeId() {
		int accountTypeId = jdbcTemplate.queryForObject(NEXT_ACCOUNT_TYPE_ID, Integer.class);
		return accountTypeId;
	}

	@Override
	public List<FixedDepositAccountDetails> getAllFixedAccount() {
		return jdbcTemplate.query(GET_ALL_FIXED_DEPOSIT_ACCOUNT, new FixedDepositAccountRowMapper());
		
	}

	public class FixedDepositAccountRowMapper implements RowMapper<FixedDepositAccountDetails> {

		@Override
		public FixedDepositAccountDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			
			String accountTypeId = rs.getString("account_type_id");
			LocalDate openingDate = rs.getDate("opening_date").toLocalDate();
			LocalDate maturityDate = rs.getDate("maturity_date").toLocalDate();
			double initialAmount = rs.getDouble("initial_amount");
			double maturityAmount = rs.getDouble("maturity_amount");
			
			FixedDepositRateOfInterest fixedDepositRateOfInterest = new FixedDepositRateOfInterest();
			fixedDepositRateOfInterest.setFdId(rs.getString("fd_id"));
			
			FixedDepositAccountDetails fixedDepositAccountDetails = new FixedDepositAccountDetails(accountTypeId, openingDate, maturityDate, initialAmount, maturityAmount, fixedDepositRateOfInterest);
			return fixedDepositAccountDetails;
		}
		
	}
}
