package com.inb.main.domain;

import java.time.LocalDate;
import java.util.Objects;

public class CurrentAccountDetails {
	private String accountTypeId;
	private LocalDate openingDate;
	private double intialOverdraftBalance;
	private double currentOverdraftBalance;
	private double currentBalance;
	
	public CurrentAccountDetails() {
		// TODO Auto-generated constructor stub
	}

	public CurrentAccountDetails(String accountTypeId, LocalDate openingDate, double intialOverdraftBalance,
			double currentOverdraftBalance, double currentBalance) {
		super();
		this.accountTypeId = accountTypeId;
		this.openingDate = openingDate;
		this.intialOverdraftBalance = intialOverdraftBalance;
		this.currentOverdraftBalance = currentOverdraftBalance;
		this.currentBalance = currentBalance;
	}

	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public double getIntialOverdraftBalance() {
		return intialOverdraftBalance;
	}

	public void setIntialOverdraftBalance(double intialOverdraftBalance) {
		this.intialOverdraftBalance = intialOverdraftBalance;
	}

	public double getCurrentOverdraftBalance() {
		return currentOverdraftBalance;
	}

	public void setCurrentOverdraftBalance(double currentOverdraftBalance) {
		this.currentOverdraftBalance = currentOverdraftBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "CurrentAccountDetails [accountTypeId=" + accountTypeId + ", openingDate=" + openingDate
				+ ", intialOverdraftBalance=" + intialOverdraftBalance + ", currentOverdraftBalance="
				+ currentOverdraftBalance + ", currentBalance=" + currentBalance + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(accountTypeId, currentBalance, currentOverdraftBalance, intialOverdraftBalance,
				openingDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CurrentAccountDetails other = (CurrentAccountDetails) obj;
		return Objects.equals(accountTypeId, other.accountTypeId)
				&& Double.doubleToLongBits(currentBalance) == Double.doubleToLongBits(other.currentBalance)
				&& Double.doubleToLongBits(currentOverdraftBalance) == Double
						.doubleToLongBits(other.currentOverdraftBalance)
				&& Double.doubleToLongBits(intialOverdraftBalance) == Double
						.doubleToLongBits(other.intialOverdraftBalance)
				&& Objects.equals(openingDate, other.openingDate);
	}
	
	

}
