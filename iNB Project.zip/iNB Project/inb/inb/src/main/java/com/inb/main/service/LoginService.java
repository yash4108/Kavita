package com.inb.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.Login;
import com.inb.main.repository.LoginRepositoryInterface;

@Service
public class LoginService implements LoginServiceInterface {
	
	@Autowired
	private LoginRepositoryInterface loginRepository;

	@Override
	public Login verifyUser(Login login) {
		return loginRepository.verifyUser(login);
	}



	@Override
	public Login addNewLogin(Login login) {
		return loginRepository.addNewLogin(login);
	}
		
}
