package com.inb.main.service;

import java.util.List;

import com.inb.main.domain.CustomerDetails;

public interface CustomerDetailsServiceInterface {

	public CustomerDetails addNewCustomer(CustomerDetails customerDetails);
	
	public List<CustomerDetails> getCustomers();
	
	public List<CustomerDetails> getPendingStatusDetails();
	
	public boolean updateStatus(CustomerDetails customerDetails);
	
	public boolean rejectCustomer(CustomerDetails customerDetails);
	
	public List<CustomerDetails> getCustomerByCustomerId(String customerId);
}
