package com.inb.main.repository;

import com.inb.main.domain.Login;

public interface LoginRepositoryInterface {
	
	public Login verifyUser(Login login);
	public int getNextLoginId();
	public Login addNewLogin(Login login);
	
	
}
