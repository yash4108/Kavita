package com.inb.main.service;

import java.util.List;

import com.inb.main.domain.BankSlipDetails;

public interface BankSlipDetailsServiceInterface {
	public BankSlipDetails addNewBankSlip(BankSlipDetails bankSlipDetails);

	public int getNextBankSlipId();
	List<BankSlipDetails> getAllBankSlipDetails(String accountId); 

}
