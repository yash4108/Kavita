package com.inb.main.domain;

import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

public class BankSlipDetails {
private String slipId;
private LocalDate slipDate;
private ChequeDetails chequeDetails;
private LocalDate chequeDate;
private String payerBank;
private String payerAccountId;
private double amount;
private AccountDetails accountDetails;

public BankSlipDetails() {
}

public BankSlipDetails(String slipId, LocalDate slipDate, ChequeDetails chequeDetails, LocalDate chequeDate,
		String payerBank, String payerAccountId, double amount, AccountDetails accountDetails) {
	super();
	this.slipId = slipId;
	this.slipDate = slipDate;
	this.chequeDetails = chequeDetails;
	this.chequeDate = chequeDate;
	this.payerBank = payerBank;
	this.payerAccountId = payerAccountId;
	this.amount = amount;
	this.accountDetails = accountDetails;
}

public String getSlipId() {
	return slipId;
}

public void setSlipId(String slipId) {
	this.slipId = slipId;
}

public LocalDate getSlipDate() {
	return slipDate;
}

public void setSlipDate(LocalDate slipDate) {
	this.slipDate = slipDate;
}

public ChequeDetails getChequeDetails() {
	return chequeDetails;
}

public void setChequeDetails(ChequeDetails chequeDetails) {
	this.chequeDetails = chequeDetails;
}

public LocalDate getChequeDate() {
	return chequeDate;
}

public void setChequeDate(LocalDate chequeDate) {
	this.chequeDate = chequeDate;
}

public String getPayerBank() {
	return payerBank;
}

public void setPayerBank(String payerBank) {
	this.payerBank = payerBank;
}

public String getPayerAccountId() {
	return payerAccountId;
}

public void setPayerAccountId(String payerAccountId) {
	this.payerAccountId = payerAccountId;
}

public double getAmount() {
	return amount;
}

public void setAmount(double amount) {
	this.amount = amount;
}

public AccountDetails getAccountDetails() {
	return accountDetails;
}

public void setAccountDetails(AccountDetails accountDetails) {
	this.accountDetails = accountDetails;
}

@Override
public int hashCode() {
	return Objects.hash(accountDetails, amount, chequeDate, chequeDetails, payerAccountId, payerBank, slipDate, slipId);
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	BankSlipDetails other = (BankSlipDetails) obj;
	return Objects.equals(accountDetails, other.accountDetails)
			&& Double.doubleToLongBits(amount) == Double.doubleToLongBits(other.amount)
			&& Objects.equals(chequeDate, other.chequeDate) && Objects.equals(chequeDetails, other.chequeDetails)
			&& Objects.equals(payerAccountId, other.payerAccountId) && Objects.equals(payerBank, other.payerBank)
			&& Objects.equals(slipDate, other.slipDate) && Objects.equals(slipId, other.slipId);
}

@Override
public String toString() {
	return "BankSlipDetails [slipId=" + slipId + ", slipDate=" + slipDate + ", chequeDetails=" + chequeDetails
			+ ", chequeDate=" + chequeDate + ", payerBank=" + payerBank + ", payerAccountId=" + payerAccountId
			+ ", amount=" + amount + ", accountDetails=" + accountDetails + "]";
}



}
