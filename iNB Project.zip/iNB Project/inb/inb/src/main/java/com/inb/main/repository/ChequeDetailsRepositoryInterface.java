package com.inb.main.repository;

import java.util.List;

import com.inb.main.domain.ChequeDetails;

public interface ChequeDetailsRepositoryInterface {

	public ChequeDetails addNewChequeDetails(ChequeDetails chequeDetails);
	
	public int getNextChequeNo();
	
	public List<ChequeDetails> getAllChequeDetails(); 
}
