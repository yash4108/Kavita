package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.CustomerDetails;
import com.inb.main.repository.CustomerDetailsRepositoryInterface;

@Service
public class CustomerDetailsService implements CustomerDetailsServiceInterface {

	@Autowired
	private CustomerDetailsRepositoryInterface customerDetailsRepository;
	
	@Override
	public CustomerDetails addNewCustomer(CustomerDetails customerDetails) {
		return customerDetailsRepository.addNewCustomer(customerDetails);
	}

	@Override
	public List<CustomerDetails> getCustomers() {
		return customerDetailsRepository.getCustomers();
	}

	@Override
	public List<CustomerDetails> getPendingStatusDetails() {
		return customerDetailsRepository.getPendingStatusDetails();
	}

	@Override
	public boolean updateStatus(CustomerDetails customerDetails) {
		return customerDetailsRepository.updateStatus(customerDetails);
	}

	@Override
	public boolean rejectCustomer(CustomerDetails customerDetails) {
		return customerDetailsRepository.rejectCustomer(customerDetails);
	}

	@Override
	public List<CustomerDetails> getCustomerByCustomerId(String customerId) {
		return customerDetailsRepository.getCustomerByCustomerId(customerId);
	}

	
}
