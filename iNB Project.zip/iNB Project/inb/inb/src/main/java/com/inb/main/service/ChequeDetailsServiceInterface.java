package com.inb.main.service;

import java.util.List;

import com.inb.main.domain.ChequeDetails;

public interface ChequeDetailsServiceInterface {

public ChequeDetails addNewChequeDetails(ChequeDetails chequeDetails);
	
	public int getNextChequeNo();
	
	public List<ChequeDetails> getAllChequeDetails(); 
}
