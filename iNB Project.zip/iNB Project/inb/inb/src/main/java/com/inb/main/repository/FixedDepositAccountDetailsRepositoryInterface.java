package com.inb.main.repository;

import java.util.List;

import com.inb.main.domain.CurrentAccountDetails;
import com.inb.main.domain.FixedDepositAccountDetails;

public interface FixedDepositAccountDetailsRepositoryInterface {
	public FixedDepositAccountDetails addNewCustomer(FixedDepositAccountDetails fixedDepositAccountDetails);

	public int getNextAccountTypeId();

	public List<FixedDepositAccountDetails> getAllFixedAccount();
}
