package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.BankSlipDetails;
import com.inb.main.repository.BankSlipDetailsRepository;
import com.inb.main.repository.BankSlipDetailsRepositoryInterface;


@Service
public class BankSlipDetailsService implements BankSlipDetailsServiceInterface {
	
	@Autowired
	private BankSlipDetailsRepositoryInterface bankSlipDetailsRepository;

	@Override
	public BankSlipDetails addNewBankSlip(BankSlipDetails bankSlipDetails) {
		return bankSlipDetailsRepository.addNewBankSlip(bankSlipDetails);
	}

	@Override
	public int getNextBankSlipId() {
		return bankSlipDetailsRepository.getNextBankSlipId();
	}

	@Override
	public List<BankSlipDetails> getAllBankSlipDetails(String accountId) {
		return bankSlipDetailsRepository.getAllBankSlipDetails(accountId);
	}

}
