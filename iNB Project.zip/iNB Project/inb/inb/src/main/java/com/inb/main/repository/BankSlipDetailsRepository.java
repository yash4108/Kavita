package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.BankSlipDetails;
import com.inb.main.domain.ChequeDetails;

@Repository
public class BankSlipDetailsRepository implements BankSlipDetailsRepositoryInterface {
	
	public static final String ADD_NEW_BANK_SLIP = "insert into bank_slip_details values(?,?,?,?,?,?,?,?)";
	public static final String NEXT_BANK_SLIP_ID = "select bank_slip_details_sequence.NEXTVAL from dual";
	public static final String GET_ALL_BANK_SLIP_DETAILS = "select sd.slip_id, sd.slip_date, cd.cheque_no, sd.cheque_date, sd.payer_bank,  sd.payer_account_id, sd.amount, sd.to_account_id from bank_slip_details sd  , cheque_details cd , account_details ad  where (cd.cheque_no= sd.cheque_no and ad.account_id = sd.to_account_id) and account_id=?";
			


	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public BankSlipDetails addNewBankSlip(BankSlipDetails bankSlipDetails) {
		String slipId="BSD" + getNextBankSlipId();
		Object [] params= {slipId, bankSlipDetails.getSlipDate(), bankSlipDetails.getChequeDetails().getChequeNo(), bankSlipDetails.getChequeDate(), bankSlipDetails.getPayerBank(), bankSlipDetails.getPayerAccountId(), bankSlipDetails.getAmount(), bankSlipDetails.getAccountDetails().getAccountId()};
		if(jdbcTemplate.update(ADD_NEW_BANK_SLIP,params)>0) {
			bankSlipDetails.setSlipId(slipId);
			return bankSlipDetails;
		}
		
		return null;
	}
	
	@Override
	public int getNextBankSlipId() {
		int slipNo = jdbcTemplate.queryForObject(NEXT_BANK_SLIP_ID, Integer.class);
		return slipNo;
	}

	
	@Override
	public List<BankSlipDetails> getAllBankSlipDetails(String accountId) {
		return jdbcTemplate.query(GET_ALL_BANK_SLIP_DETAILS,new BankSlipRowmapper(),accountId);
	}


	
	
	public class BankSlipRowmapper implements RowMapper<BankSlipDetails>{

		@Override
		public BankSlipDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			String slipId=rs.getString("slip_id");
			LocalDate slipDate=rs.getDate("slip_date").toLocalDate();
			LocalDate chequeDate=rs.getDate("cheque_date").toLocalDate();
			String payerBank=rs.getString("payer_bank");
			String payerAccountId=rs.getString("payer_account_id");
			Double amount=rs.getDouble("amount");
			
			ChequeDetails chequeDetails=new ChequeDetails();
			chequeDetails.setChequeNo(rs.getString("cheque_no"));
			
			AccountDetails accountDetails=new AccountDetails();
			accountDetails.setAccountId(rs.getString("to_account_id"));
			
			BankSlipDetails bankSlipDetails=new BankSlipDetails(slipId, slipDate, chequeDetails, chequeDate, payerBank, payerAccountId, amount, accountDetails);
			
			return bankSlipDetails;
			
			
		}
		
	}

}

