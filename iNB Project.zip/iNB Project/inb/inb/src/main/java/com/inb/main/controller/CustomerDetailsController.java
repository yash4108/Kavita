package com.inb.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.CustomerDetails;
import com.inb.main.service.CustomerDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("customerdetailsapi")
public class CustomerDetailsController {
	
	@Autowired
	CustomerDetailsServiceInterface customerDetailsService;

	@RequestMapping(value = "addcustomer" , method = RequestMethod.POST)
	public CustomerDetails addNewCustomer(@RequestBody CustomerDetails customerDetails) {
		System.out.println("in controller");
		return customerDetailsService.addNewCustomer(customerDetails);
	}
	
	@RequestMapping(value = "allcustomers" , method = RequestMethod.GET)
	public List<CustomerDetails> getCustomers() {
		return customerDetailsService.getCustomers();
	}
	
	@RequestMapping(value = "getpendingstatus" , method = RequestMethod.GET)
	public List<CustomerDetails> getPendingStatusDetails() {
		return customerDetailsService.getPendingStatusDetails();
	}
	
	@RequestMapping(value = "updatestatus" , method = RequestMethod.PUT)
	public boolean updateStatus(@RequestBody CustomerDetails customerDetails) {
		return customerDetailsService.updateStatus(customerDetails);
	}
	
	@RequestMapping(value = "rejectcustomer" , method = RequestMethod.PUT)
	public boolean rejectAccount(@RequestBody CustomerDetails customerDetails) {
		return customerDetailsService.rejectCustomer(customerDetails);
	}
	
	@RequestMapping(value = "getallcustomer/{customerId}" , method = RequestMethod.GET)
	public List<CustomerDetails> getCustomerByCustomerId(@PathVariable String customerId) {
		return customerDetailsService.getCustomerByCustomerId(customerId);
	}
}
