package com.inb.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.domain.SavingAccountDetails;
import com.inb.main.service.SavingAccountDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("savingaccountapi")
public class SavingAccountDetailsController {
	
	@Autowired
	private SavingAccountDetailsServiceInterface savingAccountDetailsService;
	
	@RequestMapping(value = "addcustomer" , method = RequestMethod.POST)
	public SavingAccountDetails addSavingAccount(@RequestBody SavingAccountDetails savingAccountDetails) {
		return savingAccountDetailsService.addNewCustomer(savingAccountDetails);
	}
	
	@RequestMapping(value = "getcustomer" , method = RequestMethod.GET)
	public List<SavingAccountDetails> getAllSavingAccount(){
		return savingAccountDetailsService.getAllSavingAccount();
	}
}
