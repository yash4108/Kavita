package com.inb.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.domain.BankSlipDetails;
import com.inb.main.domain.ChequeDetails;
import com.inb.main.service.BankSlipDetailsService;
import com.inb.main.service.BankSlipDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("bankslipapi")
public class BankSlipDetailsController {

	@Autowired
	private BankSlipDetailsServiceInterface bankSlipDetailsService;
	
	@RequestMapping(value="addbankslip", method =RequestMethod.POST )
	public BankSlipDetails addNewBankSlip(@RequestBody BankSlipDetails bankSlipDetails) {
		return bankSlipDetailsService.addNewBankSlip(bankSlipDetails);
	}
	
	@RequestMapping(value = "getallbankslip/{accountId}" , method = RequestMethod.GET)
	public List<BankSlipDetails> getAllBankSlip(@PathVariable String accountId) {
		return bankSlipDetailsService.getAllBankSlipDetails(accountId);
	}
	
}
