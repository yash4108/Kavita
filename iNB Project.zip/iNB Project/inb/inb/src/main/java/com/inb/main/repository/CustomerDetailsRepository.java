package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.CustomerDetails;
import com.inb.main.domain.Login;

@Repository
public class CustomerDetailsRepository implements CustomerDetailsRepositoryInterface {
	
	Login login = new Login();

	private static final String INSERT_NEW_CUSTOMER = "insert into customer_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,'Inactive')";
	private static final String NEXT_CUSTOMER_ID = "select customer_details_sequence.NEXTVAL from dual";
	private static final String GET_ALL_CUSTOMERS = "select customer_id, first_name, last_name, address_line_1, address_line_2, address_line_3, city, state, zip, phone, cell, email, status, l.login_id, l.user_id, l.designation from customer_details c, login_details l where c.login_id = l.login_id";
	private static final String GET_PENDING_STATUS = "select customer_id, first_name, last_name, address_line_1, address_line_2, address_line_3, city, state, zip, phone, cell, email, status, l.login_id, l.user_id, l.designation  from customer_details c, login_details l where c.status='Inactive'";
	private static final String UPDATE_STATUS = "update customer_details set status='Active' where customer_id=?";
	private static final String REJECT_ACCOUNT = "update customer_details set status='Rejected' where customer_id=?";
	//private static final String GET_CUSTOMER_BY_ID = "select customer_id, first_name, last_name, address_line_1, address_line_2, address_line_3, city, state, zip, phone, cell, email, status, l.login_id, l.user_id, l.designation from customer_details c, login_details l  where c.customer_id= ?";
	private static final String GET_CUSTOMER_BY_ID = "select customer_id, first_name, last_name, address_line_1, address_line_2, address_line_3, city, state, zip, phone, cell, email, status, l.login_id, l.user_id from customer_details c, login_details l  where c.customer_id= ?";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public CustomerDetails addNewCustomer(CustomerDetails customerDetails) {
		System.out.println("in repo");
		String customerId = "CID" + getNextCustomerId();
		Object[] params = { customerId, customerDetails.getFirstName(), customerDetails.getLastName(),
				customerDetails.getAddressLine1(), customerDetails.getAddressLine2(), customerDetails.getAddressLine3(),
				customerDetails.getCity(), customerDetails.getState(), customerDetails.getZip(),
				customerDetails.getPhone(), customerDetails.getCell(), customerDetails.getEmail(),
				customerDetails.getLogin().getLoginId()};
		if (jdbcTemplate.update(INSERT_NEW_CUSTOMER, params) > 0) {
			System.out.println("in if repo");
			customerDetails.setCustomerId(customerId);
			return customerDetails;
		}
		return null;
	}
	
	@Override
	public List<CustomerDetails> getCustomers() {
		return jdbcTemplate.query(GET_ALL_CUSTOMERS, new CustomerRowMapper());
	}

	@Override
	public int getNextCustomerId() {
		int customerId = jdbcTemplate.queryForObject(NEXT_CUSTOMER_ID, Integer.class);
		return customerId;
	}
	
	@Override
	public List<CustomerDetails> getPendingStatusDetails() {
		return jdbcTemplate.query(GET_PENDING_STATUS, new CustomerRowMapper());
	}
	
	@Override
	public boolean updateStatus(CustomerDetails customerDetails) {
		int result = jdbcTemplate.update(UPDATE_STATUS, customerDetails.getCustomerId());
		if(result>0)
			return true;
		return false;
	}
	
	@Override
	public boolean rejectCustomer(CustomerDetails customerDetails) {
		int result = jdbcTemplate.update(REJECT_ACCOUNT, customerDetails.getCustomerId());
		if(result>0)
			return true;
		return false;
	}

	@Override
	public List<CustomerDetails> getCustomerByCustomerId(String customerId) {
		System.out.println(customerId);
		return jdbcTemplate.query(GET_CUSTOMER_BY_ID, new CustomerRowMapper(), customerId);
	}
	
	public class CustomerRowMapper implements RowMapper<CustomerDetails> {

		@Override
		public CustomerDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

			String customerId = rs.getString("customer_id");
			String firstName = rs.getString("first_name");
			String lastName = rs.getString("last_name");
			String addressLine1 = rs.getString("address_line_1");
			String addressLine2 = rs.getString("address_line_2");
			String addressLine3 = rs.getString("address_line_3");
			String city = rs.getString("city");
			String state = rs.getString("state");
			String zip = rs.getString("zip");
			String phone = rs.getString("phone");
			String cell = rs.getString("cell");
			String email = rs.getString("email");
			String status = rs.getString("status");

			Login login = new Login();
			login.setLoginId(rs.getString("login_id"));
			login.setUserName(rs.getString("user_id"));
//			login.setPassword(rs.getString("password"));
//			login.setDesignation(rs.getString("designation"));

			CustomerDetails customerDetails = new CustomerDetails(customerId, firstName, lastName, addressLine1, addressLine2, addressLine3, city, state, zip, phone, cell, email, login, status);

			return customerDetails;
		}
	}

	

}
