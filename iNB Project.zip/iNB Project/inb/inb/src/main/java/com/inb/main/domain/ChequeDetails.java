package com.inb.main.domain;

import java.time.LocalDate;
import java.util.Objects;

public class ChequeDetails {
	private String chequeNo;
	private LocalDate chequeDate;
	private double chequeAmount;
	private String beneficiaryName;
	private AccountDetails accountDetails;
	
	public ChequeDetails() {
		// TODO Auto-generated constructor stub
	}

	public ChequeDetails(String chequeNo, LocalDate chequeDate, double chequeAmount, String beneficiaryName,
			AccountDetails accountDetails) {
		super();
		this.chequeNo = chequeNo;
		this.chequeDate = chequeDate;
		this.chequeAmount = chequeAmount;
		this.beneficiaryName = beneficiaryName;
		this.accountDetails = accountDetails;
	}

	public String getChequeNo() {
		return chequeNo;
	}

	public void setChequeNo(String chequeNo) {
		this.chequeNo = chequeNo;
	}

	public LocalDate getChequeDate() {
		return chequeDate;
	}

	public void setChequeDate(LocalDate chequeDate) {
		this.chequeDate = chequeDate;
	}

	public double getChequeAmount() {
		return chequeAmount;
	}

	public void setChequeAmount(double chequeAmount) {
		this.chequeAmount = chequeAmount;
	}

	public String getBeneficiaryName() {
		return beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	public AccountDetails getAccountDetails() {
		return accountDetails;
	}

	public void setAccountDetails(AccountDetails accountDetails) {
		this.accountDetails = accountDetails;
	}

	@Override
	public String toString() {
		return "ChequeDetails [chequeNo=" + chequeNo + ", chequeDate=" + chequeDate + ", chequeAmount=" + chequeAmount
				+ ", beneficiaryName=" + beneficiaryName + ", accountDetails=" + accountDetails + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(accountDetails, beneficiaryName, chequeAmount, chequeDate, chequeNo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChequeDetails other = (ChequeDetails) obj;
		return Objects.equals(accountDetails, other.accountDetails)
				&& Objects.equals(beneficiaryName, other.beneficiaryName)
				&& Double.doubleToLongBits(chequeAmount) == Double.doubleToLongBits(other.chequeAmount)
				&& Objects.equals(chequeDate, other.chequeDate) && Objects.equals(chequeNo, other.chequeNo);
	}

}
