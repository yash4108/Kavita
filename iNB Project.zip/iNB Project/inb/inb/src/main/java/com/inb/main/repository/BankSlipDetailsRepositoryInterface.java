package com.inb.main.repository;

import java.util.List;

import com.inb.main.domain.BankSlipDetails;

public interface BankSlipDetailsRepositoryInterface {
	public BankSlipDetails addNewBankSlip(BankSlipDetails bankSlipDetails);

	public int getNextBankSlipId();
	

	public List<BankSlipDetails> getAllBankSlipDetails(String accountId); 


}
