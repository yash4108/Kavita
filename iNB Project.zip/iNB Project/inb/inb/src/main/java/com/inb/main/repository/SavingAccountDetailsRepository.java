package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.SavingAccountDetails;

@Repository
public class SavingAccountDetailsRepository implements SavingAccountDetailsRepositoryInterface {
	
	private static final String NEXT_ACCOUNT_TYPE_ID = "select saving_account_details_sequence.NEXTVAL from dual";
	private static final String INSERT_NEW_SAVING_ACCOUNT = "insert into saving_account_details(account_type_id, minimum_balance, current_balance, rate_of_interest) values(?,?,?,?)";
	private static final String GET_ALL_SAVING_ACCOUNT = "select * from saving_account_details";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public SavingAccountDetails addNewCustomer(SavingAccountDetails savingAccountDetails) {
		String accountTypeId = "SAID" + getNextAccountTypeId();
		Object [] params = {accountTypeId,savingAccountDetails.getMinimunBalance(),savingAccountDetails.getCurrentBalance(),savingAccountDetails.getRateOfInterest()};	
		if (jdbcTemplate.update(INSERT_NEW_SAVING_ACCOUNT,params) > 0) {
			savingAccountDetails.setAccountTypeId(accountTypeId);
			return savingAccountDetails;
		}
		return null;
	}

	@Override
	public int getNextAccountTypeId() {
		int accountTypeId =  jdbcTemplate.queryForObject(NEXT_ACCOUNT_TYPE_ID, Integer.class);
		return accountTypeId;
	}

	@Override
	public List<SavingAccountDetails> getAllSavingAccount() {
		return jdbcTemplate.query(GET_ALL_SAVING_ACCOUNT, new SavingRowMapper());
	}
	
	public class SavingRowMapper implements RowMapper<SavingAccountDetails>{

		@Override
		public SavingAccountDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			String accountTypeId = rs.getString("account_type_id");
			LocalDate openingDate = rs.getDate("opening_date").toLocalDate();
			double minimumBalance = rs.getDouble("minimum_balance");
			double currentBalance = rs.getDouble("current_balance");
			double rateOfInterest = rs.getDouble("rate_of_interest");
			
			SavingAccountDetails savingAccountDetails = new SavingAccountDetails(accountTypeId, openingDate, minimumBalance, currentBalance, rateOfInterest);
			return savingAccountDetails;
		}
		
	}
}
