package com.inb.main.service;

import java.util.List;

import com.inb.main.domain.CurrentAccountDetails;

public interface CurrentAccountDetailsServiceInterface {
	
	public CurrentAccountDetails addNewCustomer(CurrentAccountDetails currentAccountDetails);

	public List<CurrentAccountDetails> getAllCurentAccount();
	
}
