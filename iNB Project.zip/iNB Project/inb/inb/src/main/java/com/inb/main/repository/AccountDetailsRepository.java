package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.CurrentAccountDetails;
import com.inb.main.domain.CustomerDetails;
import com.inb.main.domain.FixedDepositAccountDetails;
import com.inb.main.domain.SavingAccountDetails;

@Repository
public class AccountDetailsRepository implements AccountDetailsRepositoryInterface {
	
	private static final String NEXT_ACCOUNT_ID = "select account_details_sequence.NEXTVAL from dual";
	private static final String INSERT_NEW_ACCOUNT = "insert into account_details(account_id, saving_account_type_id, current_account_type_id, fixed_deposit_account_type_id, customer_id, status) values(?,?,?,?,?,?)";
	private static final String GET_ALL_ACCOUNT = "select * from account_details";
	private static final String GET_PENDING_STATUS = "select * from account_details where status='Inactive'";
	private static final String UPDATE_STATUS = "update account_details set status='Active' where account_id=?";
	private static final String REJECT_ACCOUNT = "update account_details set status='Rejected' where account_id=?";
	private static final String GET_ACCOUNT_BY_ID = "select * from account_details where account_id=?";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public AccountDetails addNewCustomer(AccountDetails accountDetails) {
		String accountId = "INB" + getNextAccountId();
		Object [] params = {accountId, accountDetails.getSavingAccountDetails().getAccountTypeId(), accountDetails.getCurrentAccountDetails().getAccountTypeId(), accountDetails.getFixedDepositAccountDetails().getAccountTypeId(), accountDetails.getCustomerDetails().getCustomerId(), accountDetails.getStatus()};	
		if (jdbcTemplate.update(INSERT_NEW_ACCOUNT,params) > 0) {
			accountDetails.setAccountId(accountId);
			return accountDetails;
		}
		return null;
	}

	@Override
	public int getNextAccountId() {
		int accountId =  jdbcTemplate.queryForObject(NEXT_ACCOUNT_ID, Integer.class);
		return accountId;
	}

	@Override
	public List<AccountDetails> getAllAccounts() {
		return jdbcTemplate.query(GET_ALL_ACCOUNT, new AccountRowMapper());
	}
	
	@Override
	public List<AccountDetails> getPendingStatusDetails() {
		return jdbcTemplate.query(GET_PENDING_STATUS, new AccountRowMapper());
	}
	
	@Override
	public boolean updateStatus(AccountDetails accountDetails) {
		int result = jdbcTemplate.update(UPDATE_STATUS, accountDetails.getAccountId());
		if(result>0)
			return true;
		return false;
	}

	@Override
	public boolean rejectAccount(AccountDetails accountDetails) {
		int result = jdbcTemplate.update(REJECT_ACCOUNT, accountDetails.getAccountId());
		if(result>0)
			return true;
		return false;
	}
	
	@Override
	public List<AccountDetails> getAccountByAccountId(String accountId) {
		return jdbcTemplate.query(GET_ACCOUNT_BY_ID,new AccountRowMapper() , accountId);
	}
	
	public class AccountRowMapper implements RowMapper<AccountDetails> {

		@Override
		public AccountDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			String accountId = rs.getString("account_id");
			
			SavingAccountDetails savingAccountDetails = new SavingAccountDetails();
			savingAccountDetails.setAccountTypeId(rs.getString("saving_account_type_id"));
			
			CurrentAccountDetails currentAccountDetails = new CurrentAccountDetails();
			currentAccountDetails.setAccountTypeId(rs.getString("current_account_type_id"));
			
			FixedDepositAccountDetails fixedDepositAccountDetails = new FixedDepositAccountDetails();
			fixedDepositAccountDetails.setAccountTypeId(rs.getString("fixed_deposit_account_type_id"));
			
			CustomerDetails customerDetails = new CustomerDetails();
			customerDetails.setCustomerId(rs.getString("customer_id"));
			
			String status = rs.getString("status");
			
			AccountDetails accountDetails = new AccountDetails(accountId, savingAccountDetails, currentAccountDetails, fixedDepositAccountDetails, customerDetails, status);
			
			return accountDetails;
		}
		
	}

}
