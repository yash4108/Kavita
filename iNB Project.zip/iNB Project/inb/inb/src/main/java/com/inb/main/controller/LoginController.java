package com.inb.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.domain.Login;
import com.inb.main.service.LoginServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("loginapi")
public class LoginController {
	
	@Autowired
	private LoginServiceInterface loginService;
	
	@RequestMapping(value = "login" , method = RequestMethod.POST)
	public Login verifyUser(@RequestBody Login login) {
		System.out.println(login);
		return loginService.verifyUser(login);
		
	}
	
	@RequestMapping(value = "newlogin" , method = RequestMethod.POST)
	public Login addNewLogin(@RequestBody Login login) {
		System.out.println("in controller");
		return loginService.addNewLogin(login);
	}
		
}
