package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.ChequeDetails;

@Repository
public class ChequeDetailsRepository implements ChequeDetailsRepositoryInterface {

	public static final String INSERT_NEW_CHEQUE = "insert into cheque_details values(?,?,?,?,?)";
	public static final String NEXT_CHEQUE_NO = "select cheque_details_sequence.NEXTVAL from dual";
	public static final String GET_CHEQUE_DETAILS = "select chequeNo, chequeDate, chequeAmount, beneficiaryName, a.accountId from cheque_details c, account_details a where c.from_account_id = a.account_id";
	
	@Autowired
	private JdbcTemplate jdbcTemplate; 
	
	@Override
	public ChequeDetails addNewChequeDetails(ChequeDetails chequeDetails) {
		String chequeNo = "CHQ" + getNextChequeNo(); 
		Object [] params = {chequeNo, chequeDetails.getChequeDate(), chequeDetails.getChequeAmount(), chequeDetails.getBeneficiaryName(), chequeDetails.getAccountDetails().getAccountId()};
		if(jdbcTemplate.update(INSERT_NEW_CHEQUE, params) > 0) {
			chequeDetails.setChequeNo(chequeNo);
			return chequeDetails;
		}
		return null;
	}

	@Override
	public int getNextChequeNo() {
		int chequeNo = jdbcTemplate.queryForObject(NEXT_CHEQUE_NO, Integer.class);
		return chequeNo;
	}

	@Override
	public List<ChequeDetails> getAllChequeDetails() {	
		return jdbcTemplate.query(GET_CHEQUE_DETAILS, new ChequeRowMapper());
	}

	public class ChequeRowMapper implements RowMapper<ChequeDetails> {

		@Override
		public ChequeDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			String chequeNo = rs.getString("cheque_no");
			LocalDate chequeDate = rs.getDate("cheque_date").toLocalDate();
			double chequeAmount = rs.getDouble("cheque_amount"); 
			String beneficiaryName = rs.getString("beneficiary_name");
			
			
			AccountDetails accountDetails = new AccountDetails();
			accountDetails.setAccountId(rs.getString("account_id"));
			
			ChequeDetails chequeDetails = new ChequeDetails(chequeNo, chequeDate, chequeAmount, beneficiaryName, accountDetails);
			return chequeDetails;
		}
		
	}
}
