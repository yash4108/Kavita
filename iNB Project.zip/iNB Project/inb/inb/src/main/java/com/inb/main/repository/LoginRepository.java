package com.inb.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.inb.main.domain.Login;

@Repository
public class LoginRepository implements LoginRepositoryInterface {
	
	private static final String NEXT_LOGIN_ID = "select login_details_sequence.NEXTVAL from dual";
	private static final String VERIFY_USER= "Select * from login_details where user_id = ? and password = ?";  
	private static final String ADD_NEW_LOGIN = "insert into login_details values(?,?,?,?)";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public Login verifyUser(Login login) {
		System.out.println(login);
		return jdbcTemplate.queryForObject(VERIFY_USER, new LoginRowMapper(), login.getUserName(), login.getPassword());
	}
	
	@Override
	public int getNextLoginId() {
		int loginId =  jdbcTemplate.queryForObject(NEXT_LOGIN_ID, Integer.class);
		return loginId;
	}

	@Override
	public Login addNewLogin(Login login) {
		String loginId = "LID" + getNextLoginId();
		Object [] params = {loginId, login.getUserName(), login.getPassword(), login.getDesignation()};
		if (jdbcTemplate.update(ADD_NEW_LOGIN , params) > 0) {
			login.setLoginId(loginId);
			return login;			
		}
		return null;
	}
	
	
	
	public class LoginRowMapper implements RowMapper<Login>{

		@Override
		public Login mapRow(ResultSet rs, int rowNum) throws SQLException {
			String loginId = rs.getString("login_id");
			String userName = rs.getString("user_id");
			String password = rs.getString("password");
			String designation = rs.getString("designation");
			
			Login login = new Login(loginId,userName,password,designation);
			return login;
		}

		
	}
}
