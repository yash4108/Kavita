package com.inb.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.inb.main.domain.FixedDepositAccountDetails;

import com.inb.main.service.FixedDepositAccountDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("fixeddepositaccountapi")
public class FixedDepositAccountDetailsController {
	@Autowired
	private FixedDepositAccountDetailsServiceInterface fixedDepositAccountDetailsService;

	@RequestMapping(value = "addcustomer" , method = RequestMethod.POST)
	public FixedDepositAccountDetails addNewCustomer(@RequestBody FixedDepositAccountDetails fixedDepositAccountDetails) {
		System.out.println("in controller");
		return fixedDepositAccountDetailsService.addNewCustomer(fixedDepositAccountDetails);
	}
	
	@RequestMapping(value = "getcustomers" , method = RequestMethod.GET)
	public List<FixedDepositAccountDetails> getCustomers() {
		return fixedDepositAccountDetailsService.getAllFixedAccount();
	}
}
