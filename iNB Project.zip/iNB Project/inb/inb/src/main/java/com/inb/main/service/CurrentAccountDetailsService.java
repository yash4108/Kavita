package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.CurrentAccountDetails;
import com.inb.main.repository.CurrentAccountDetailsRepository;
import com.inb.main.repository.CurrentAccountDetailsRepositoryInterface;

@Service
public class CurrentAccountDetailsService implements CurrentAccountDetailsServiceInterface {

	@Autowired
	private CurrentAccountDetailsRepositoryInterface currentAccountDetailsRepository;

	@Override
	public CurrentAccountDetails addNewCustomer(CurrentAccountDetails currentAccountDetails) {

		return currentAccountDetailsRepository.addNewCustomer(currentAccountDetails);
	}

	@Override
	public List<CurrentAccountDetails> getAllCurentAccount() {

		return currentAccountDetailsRepository.getAllCurentAccount();
	}

}
