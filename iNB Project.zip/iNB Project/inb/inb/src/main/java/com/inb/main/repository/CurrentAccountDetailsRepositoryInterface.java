package com.inb.main.repository;

import java.util.List;

import com.inb.main.domain.AccountDetails;
import com.inb.main.domain.CurrentAccountDetails;
import com.inb.main.domain.SavingAccountDetails;



public interface CurrentAccountDetailsRepositoryInterface {
	
	public CurrentAccountDetails addNewCustomer(CurrentAccountDetails currentAccountDetails);

	public int getNextAccountTypeId();
	
	public List<CurrentAccountDetails> getAllCurentAccount();

}
