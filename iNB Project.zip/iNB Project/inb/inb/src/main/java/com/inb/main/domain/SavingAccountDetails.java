package com.inb.main.domain;

import java.time.LocalDate;
import java.util.Objects;

public class SavingAccountDetails {
	private String accountTypeId;
	private LocalDate openingDate;
	private double minimunBalance;
	private double currentBalance;
	private double rateOfInterest;
	
	public SavingAccountDetails() {
		// TODO Auto-generated constructor stub
	}

	public SavingAccountDetails(String accountTypeId, LocalDate openingDate, double minimunBalance,
			double currentBalance, double rateOfInterest) {
		super();
		this.accountTypeId = accountTypeId;
		this.openingDate = openingDate;
		this.minimunBalance = minimunBalance;
		this.currentBalance = currentBalance;
		this.rateOfInterest = rateOfInterest;
	}

	public String getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(String accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public LocalDate getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDate openingDate) {
		this.openingDate = openingDate;
	}

	public double getMinimunBalance() {
		return minimunBalance;
	}

	public void setMinimunBalance(double minimunBalance) {
		this.minimunBalance = minimunBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	@Override
	public String toString() {
		return "SavingAccountDetails [accountTypeId=" + accountTypeId + ", openingDate=" + openingDate
				+ ", minimunBalance=" + minimunBalance + ", currentBalance=" + currentBalance + ", rateOfInterest="
				+ rateOfInterest + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(accountTypeId, currentBalance, minimunBalance, openingDate, rateOfInterest);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SavingAccountDetails other = (SavingAccountDetails) obj;
		return Objects.equals(accountTypeId, other.accountTypeId)
				&& Double.doubleToLongBits(currentBalance) == Double.doubleToLongBits(other.currentBalance)
				&& Double.doubleToLongBits(minimunBalance) == Double.doubleToLongBits(other.minimunBalance)
				&& Objects.equals(openingDate, other.openingDate)
				&& Double.doubleToLongBits(rateOfInterest) == Double.doubleToLongBits(other.rateOfInterest);
	}
	
	
	
}
