package com.inb.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inb.main.domain.AccountDetails;
import com.inb.main.repository.AccountDetailsRepositoryInterface;

@Service
public class AccountDetailsService implements AccountDetailsServiceInterface {
	
	@Autowired
	private AccountDetailsRepositoryInterface accountDetailsRepository;
	
	@Override
	public AccountDetails addNewCustomer(AccountDetails accountDetails) {
		return accountDetailsRepository.addNewCustomer(accountDetails);
	}

	@Override
	public List<AccountDetails> getAllAccounts() {
		return accountDetailsRepository.getAllAccounts();
	}

	@Override
	public List<AccountDetails> getPendingStatusDetails() {
		return accountDetailsRepository.getPendingStatusDetails();
	}

	@Override
	public boolean updateStatus(AccountDetails accountDetails) {
		return accountDetailsRepository.updateStatus(accountDetails);
	}

	@Override
	public boolean rejectAccount(AccountDetails accountDetails) {
		return accountDetailsRepository.rejectAccount(accountDetails);
	}

	@Override
	public List<AccountDetails> getAccountByAccountId(String accountId) {
		
		return accountDetailsRepository.getAccountByAccountId(accountId);
	}

}
