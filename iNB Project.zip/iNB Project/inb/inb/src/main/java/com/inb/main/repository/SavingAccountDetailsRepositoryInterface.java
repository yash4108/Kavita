package com.inb.main.repository;

import java.util.List;

import com.inb.main.domain.SavingAccountDetails;

public interface SavingAccountDetailsRepositoryInterface {
	
	public SavingAccountDetails addNewCustomer(SavingAccountDetails savingAccountDetails);
	
	public int getNextAccountTypeId();
	
	public List<SavingAccountDetails> getAllSavingAccount();
}
