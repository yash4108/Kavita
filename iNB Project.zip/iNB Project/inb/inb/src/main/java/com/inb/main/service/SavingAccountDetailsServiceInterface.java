package com.inb.main.service;

import java.util.List;

import com.inb.main.domain.SavingAccountDetails;

public interface SavingAccountDetailsServiceInterface {
	
	public SavingAccountDetails addNewCustomer(SavingAccountDetails savingAccountDetails);

	public List<SavingAccountDetails> getAllSavingAccount();
	
}
