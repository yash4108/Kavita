package com.inb.main.repository;

import java.util.List;

import com.inb.main.domain.AccountDetails;

public interface AccountDetailsRepositoryInterface {

	public AccountDetails addNewCustomer(AccountDetails accountDetails);

	public int getNextAccountId();

	public List<AccountDetails> getAllAccounts(); 
	
	public List<AccountDetails> getPendingStatusDetails();
	
	public boolean updateStatus(AccountDetails accountDetails);
	
	public boolean rejectAccount(AccountDetails accountDetails);
	
	public List<AccountDetails> getAccountByAccountId(String accountId);
}
