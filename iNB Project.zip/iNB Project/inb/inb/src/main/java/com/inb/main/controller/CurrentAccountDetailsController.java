package com.inb.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inb.main.domain.CurrentAccountDetails;
import com.inb.main.service.CurrentAccountDetailsServiceInterface;


@CrossOrigin("*")
@RestController
@RequestMapping("currentaccountapi")
public class CurrentAccountDetailsController {
	@Autowired
	private CurrentAccountDetailsServiceInterface currentAccountDetailsService;

	@RequestMapping(value = "addcustomer", method = RequestMethod.POST)
	public CurrentAccountDetails addCurrentAccount(@RequestBody CurrentAccountDetails currentAccountDetails) {
		return currentAccountDetailsService.addNewCustomer(currentAccountDetails);
	}

	@RequestMapping(value = "getcustomer", method = RequestMethod.GET)
	public List<CurrentAccountDetails> getAllCurrentAccount() {
		return currentAccountDetailsService.getAllCurentAccount();
	}

}
